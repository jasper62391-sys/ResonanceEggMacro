package com.example.resonanceeggmacro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(41, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("macro", "Macro controls", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "macro") else Notification.Builder(this)
        return builder.setContentTitle("Resonance Egg Macro")
            .setContentText("플로팅 매크로 버튼이 실행 중입니다.")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
    }

    private fun showPanel() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
            setBackgroundColor(0xDD20242A.toInt())
        }
        val header = Button(this).apply { text = "≡ 이동 / 매크로" }
        val row1 = LinearLayout(this)
        val row2 = LinearLayout(this)
        fun add(parent: LinearLayout, label: String, action: () -> Unit) {
            parent.addView(Button(this).apply {
                text = label
                textSize = 11f
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, 48, 1f))
        }
        add(row1, "시작") {
            val svc = MacroAccessibilityService.instance
            if (svc == null) toast("접근성 서비스 활성화가 필요합니다.")
            else { svc.startPlayback(); toast("저장된 동작 재생 요청") }
        }
        add(row1, "정지") { MacroAccessibilityService.instance?.stopPlayback(); toast("정지") }
        add(row2, "기록") { toast("좌표 자동 녹화는 지원되지 않습니다. 앱에서 탭/드래그 좌표를 등록하세요.") }
        add(row2, "설정") {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(panel, lp); return true
                    }
                }
                return true
            }
        })
        layout.addView(header)
        layout.addView(row1)
        layout.addView(row2)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 120
        }
        panel = layout
        wm.addView(layout, lp)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
