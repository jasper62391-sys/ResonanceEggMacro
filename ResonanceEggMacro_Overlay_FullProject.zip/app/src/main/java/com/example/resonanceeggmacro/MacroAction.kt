package com.example.resonanceeggmacro

data class MacroAction(
    val type: String,
    val x: Float,
    val y: Float,
    val endX: Float = x,
    val endY: Float = y,
    val duration: Long = 100L,
    val delayAfter: Long = 300L
)
