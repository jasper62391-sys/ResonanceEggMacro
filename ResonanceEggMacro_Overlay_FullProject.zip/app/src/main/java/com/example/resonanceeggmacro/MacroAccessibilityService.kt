package com.example.resonanceeggmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var index = 0
    private var actions: List<MacroAction> = emptyList()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopPlayback() }

    fun startPlayback() {
        if (running) return
        actions = MacroStore.load(this)
        if (actions.isEmpty()) return
        running = true
        index = 0
        playNext()
    }

    fun stopPlayback() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun playNext() {
        if (!running) return
        if (index >= actions.size) index = 0
        val action = actions[index++]
        val path = Path().apply {
            moveTo(action.x, action.y)
            if (action.type == "DRAG") lineTo(action.endX, action.endY)
        }
        val duration = if (action.type == "DRAG") action.duration.coerceIn(80, 10000) else 80L
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (running) handler.postDelayed({ playNext() }, action.delayAfter.coerceIn(0, 60000))
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (running) handler.postDelayed({ playNext() }, 500)
            }
        }, handler)
        if (!accepted && running) handler.postDelayed({ playNext() }, 500)
    }

    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        stopPlayback()
        if (instance === this) instance = null
        super.onDestroy()
    }
}
