package com.example.resonanceeggmacro

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val actions = mutableListOf<MacroAction>()
    private lateinit var listText: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actions.clear()
        actions.addAll(MacroStore.load(this))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
        }
        fun text(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size }
        root.addView(text("Resonance Egg Macro", 22f))
        root.addView(text("플로팅 버튼과 좌표 기반 동작 재생 설정", 14f))
        root.addView(text("1) 다른 앱 위에 표시 권한을 허용하세요."))
        root.addView(Button(this).apply {
            text = "오버레이 권한 설정"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else toast("오버레이 권한이 이미 허용되어 있습니다.")
            }
        })
        root.addView(text("2) 접근성 서비스에서 Resonance Egg Macro를 켜세요."))
        root.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(text("3) 게임 화면 위에 플로팅 패널 실행"))
        root.addView(Button(this).apply {
            text = "플로팅 버튼 실행"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    toast("먼저 오버레이 권한을 허용하세요."); return@setOnClickListener
                }
                val i = Intent(this@MainActivity, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                toast("플로팅 버튼을 실행했습니다.")
            }
        })
        root.addView(text("동작 등록 (화면 좌표 기준)", 18f))
        val x = field("시작 X 좌표")
        val y = field("시작 Y 좌표")
        val ex = field("드래그 끝 X 좌표 (탭이면 비워두기)")
        val ey = field("드래그 끝 Y 좌표 (탭이면 비워두기)")
        val delay = field("동작 후 대기시간 ms (예: 500)")
        root.addView(x); root.addView(y); root.addView(ex); root.addView(ey); root.addView(delay)
        root.addView(Button(this).apply {
            text = "탭 동작 추가"
            setOnClickListener {
                val px = x.num(); val py = y.num()
                if (px == null || py == null) toast("X와 Y 좌표를 숫자로 입력하세요.")
                else addAction(MacroAction("TAP", px, py, delayAfter = delay.num()?.toLong() ?: 500L))
            }
        })
        root.addView(Button(this).apply {
            text = "드래그 동작 추가"
            setOnClickListener {
                val px=x.num(); val py=y.num(); val qx=ex.num(); val qy=ey.num()
                if (px==null || py==null || qx==null || qy==null) toast("시작/끝 좌표를 모두 입력하세요.")
                else addAction(MacroAction("DRAG", px, py, qx, qy, 500L, delay.num()?.toLong() ?: 500L))
            }
        })
        root.addView(Button(this).apply {
            text = "동작 전체 삭제"
            setOnClickListener { actions.clear(); MacroStore.save(this@MainActivity, actions); refresh() }
        })
        listText = text("", 13f)
        root.addView(listText)
        root.addView(text("주의: Android 접근성 서비스는 저장한 동작을 재생합니다. 다른 앱의 게임 터치를 좌표 그대로 자동 녹화하는 기능은 Android 제약으로 포함하지 않았습니다. 게임에서 동작이 허용되는지는 직접 확인해야 합니다.", 12f))
        refresh()
        setContentView(root)
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setSingleLine(true)
    }
    private fun EditText.num(): Float? = text.toString().trim().toFloatOrNull()
    private fun addAction(a: MacroAction) {
        actions += a
        MacroStore.save(this, actions)
        refresh()
        toast("동작을 저장했습니다.")
    }
    private fun refresh() {
        if (::listText.isInitialized) listText.text = "저장된 동작: ${actions.size}개\n" +
            actions.mapIndexed { i, a -> "${i+1}. ${a.type} (${a.x}, ${a.y})" +
                if (a.type == "DRAG") " → (${a.endX}, ${a.endY})" else "" }.joinToString("\n")
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
