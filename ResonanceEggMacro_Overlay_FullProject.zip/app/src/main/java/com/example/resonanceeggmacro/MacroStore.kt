package com.example.resonanceeggmacro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object MacroStore {
    private const val PREF = "macro_settings"
    private const val KEY = "actions"

    fun load(context: Context): MutableList<MacroAction> {
        val raw = context.getSharedPreferences(PREF, 0).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val result = mutableListOf<MacroAction>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result += MacroAction(
                o.getString("type"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
                o.optDouble("endX", o.getDouble("x")).toFloat(),
                o.optDouble("endY", o.getDouble("y")).toFloat(),
                o.optLong("duration", 100), o.optLong("delayAfter", 300)
            )
        }
        return result
    }

    fun save(context: Context, actions: List<MacroAction>) {
        val arr = JSONArray()
        actions.forEach { a ->
            arr.put(JSONObject().put("type", a.type).put("x", a.x).put("y", a.y)
                .put("endX", a.endX).put("endY", a.endY)
                .put("duration", a.duration).put("delayAfter", a.delayAfter))
        }
        context.getSharedPreferences(PREF, 0).edit().putString(KEY, arr.toString()).apply()
    }
}
