# Resonance Egg Macro (Overlay build)

## 포함된 기능
- 다른 앱 위에 표시되는 이동 가능한 플로팅 패널
- 시작 / 정지 버튼
- 앱 화면에서 좌표를 입력해 탭 및 드래그 동작 등록
- Android AccessibilityService `dispatchGesture()`를 이용한 저장 동작 재생
- 동작 목록을 앱 내부 SharedPreferences에 저장

## 아직 구현되지 않은 기능
- 게임 화면 터치의 자동 좌표 녹화: Android 접근성 API는 일반 게임의 원시 터치 좌표를 그대로 제공하지 않으므로 이 프로젝트에는 포함하지 않았습니다.
- NPC 대화 인식 및 선택, 알 받기, 건물 출입, 경로 자동 판단
- 게임별 입력 호환성 보장

## 빌드
JDK 17, Android SDK 35, Gradle 8.9 환경에서:
`gradle assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## 설치 후 사용
1. 앱 실행
2. 다른 앱 위에 표시 권한 허용
3. Android 설정 > 접근성 > 설치된 앱(또는 다운로드한 앱) > Resonance Egg Macro 활성화
4. 앱으로 돌아와 플로팅 버튼 실행
5. 게임 해상도 기준 화면 좌표를 앱에서 입력해 탭/드래그 동작을 저장
6. 게임 위 플로팅 패널의 시작/정지로 재생

접근성 권한은 사용자가 직접 설정에서 켜야 합니다. 재생 중에는 게임 화면 크기/방향/해상도 변경 시 좌표를 다시 설정해야 합니다.
