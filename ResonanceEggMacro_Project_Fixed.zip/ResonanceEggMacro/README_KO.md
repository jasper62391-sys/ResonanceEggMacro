# Resonance Egg Macro

이 프로젝트는 Android APK 빌드 확인을 위한 기본 프로젝트입니다.

현재 포함된 기능:
- Android 앱 기본 화면
- Gradle 멀티모듈 설정
- Java/Kotlin JVM target 17 설정

아직 구현되지 않은 기능:
- 게임 터치/드래그 자동화
- NPC 대화창 인식 및 선택
- 알 받기 및 부화 경로 반복
