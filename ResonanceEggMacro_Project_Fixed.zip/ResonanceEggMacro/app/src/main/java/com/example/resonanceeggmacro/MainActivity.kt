package com.example.resonanceeggmacro

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Resonance Egg Macro"
            textSize = 24f
        }

        val message = TextView(this).apply {
            text = "Build test project\n\nThis is a clean Android project skeleton.\nMacro recording, game input, and dialogue selection are not implemented yet."
            textSize = 16f
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(message)
        setContentView(layout)
    }
}
