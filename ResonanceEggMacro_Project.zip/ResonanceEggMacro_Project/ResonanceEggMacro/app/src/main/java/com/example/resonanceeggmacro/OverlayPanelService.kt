package com.example.resonanceeggmacro

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayPanelService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(0xEE20242A.toInt())
        }
        box.addView(TextView(this).apply {
            text = "알 부화 매크로"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
        })
        box.addView(Button(this).apply {
            text = "시작"
            setOnClickListener {
                if (MacroRunner.service == null) {
                    Toast.makeText(this@OverlayPanelService, "접근성 서비스를 먼저 켜세요.", Toast.LENGTH_LONG).show()
                } else {
                    MacroRunner.start()
                    Toast.makeText(this@OverlayPanelService, "반복 시작", Toast.LENGTH_SHORT).show()
                }
            }
        })
        box.addView(Button(this).apply {
            text = "정지"
            setOnClickListener { MacroRunner.stop() }
        })
        box.addView(Button(this).apply {
            text = "패널 닫기"
            setOnClickListener { MacroRunner.stop(); stopSelf() }
        })
        panel = box

        val params = WindowManager.LayoutParams(
            dp(170), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12); y = dp(100)
        }
        windowManager?.addView(box, params)
    }

    override fun onDestroy() {
        MacroRunner.stop()
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
