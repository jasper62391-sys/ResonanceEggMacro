package com.example.resonanceeggmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { MacroRunner.stop() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        MacroRunner.service = this
    }

    override fun onDestroy() {
        MacroRunner.stop()
        if (MacroRunner.service === this) MacroRunner.service = null
        super.onDestroy()
    }

    fun swipe(points: List<Pair<Float, Float>>, durationMs: Long, done: (() -> Unit)? = null) {
        if (points.size < 2) { done?.invoke(); return }
        val path = Path().apply {
            moveTo(points.first().first, points.first().second)
            points.drop(1).forEach { lineTo(it.first, it.second) }
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(80))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done?.invoke() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done?.invoke() }
        }, null)
    }
}

object MacroRunner {
    var service: MacroAccessibilityService? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile var running = false
        private set

    // Placeholder screen coordinates; user must calibrate these for their own display/game.
    var startX = 500f
    var startY = 1200f
    var downY = 1300f
    var rightX = 850f
    var segmentMs = 1200L
    var pauseMs = 350L

    private var phase = 0
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val s = service
            if (s == null) { stop(); return }
            val path = when (phase) {
                0 -> listOf(startX to startY, startX to downY)                 // short downward segment
                1 -> listOf(startX to downY, rightX to downY)                 // straight outward
                2 -> listOf(rightX to downY, startX to downY)                 // straight return
                else -> listOf(startX to downY, startX to startY)             // return to start
            }
            s.swipe(path, segmentMs) {
                if (!running) return@swipe
                phase = (phase + 1) % 4
                handler.postDelayed(this, pauseMs)
            }
        }
    }

    fun start() {
        if (running) return
        if (service == null) return
        running = true
        phase = 0
        handler.post(loop)
    }
    fun stop() {
        running = false
        handler.removeCallbacks(loop)
    }
}
