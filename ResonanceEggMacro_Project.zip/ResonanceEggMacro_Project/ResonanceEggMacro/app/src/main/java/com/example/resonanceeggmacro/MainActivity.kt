package com.example.resonanceeggmacro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "레조넌스 반복 터치 매크로"
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "1) 다른 앱 위에 표시 권한과 접근성 서비스를 켜세요.\\n2) 게임으로 돌아가 떠 있는 패널에서 시작하세요.\\n3) 먼저 안전한 장소에서 짧게 시험하세요."
            textSize = 15f
            setPadding(0, dp(12), 0, dp(12))
        })

        val overlayButton = Button(this).apply {
            text = "다른 앱 위에 표시 권한 설정"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "권한이 이미 허용되어 있어요.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(overlayButton)

        root.addView(Button(this).apply {
            text = "접근성 서비스 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "게임 위에 조작 패널 표시"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "먼저 오버레이 권한을 허용하세요.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, OverlayPanelService::class.java))
                    Toast.makeText(this@MainActivity, "게임으로 돌아가 패널을 사용하세요.", Toast.LENGTH_SHORT).show()
                }
            }
        })

        root.addView(TextView(this).apply {
            text = "\\n주의: 이 버전은 터치 자동화의 기본 골격입니다. 게임의 NPC 대화·메뉴 선택·출입 동작은 화면 좌표를 확인한 뒤 별도로 설정해야 합니다. 접근성 권한은 직접 켜고, 사용하지 않을 때는 꺼 주세요."
            textSize = 13f
        })
        setContentView(root)
    }
}
